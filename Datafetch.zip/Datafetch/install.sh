# Esempio di script di installazione (install.sh)
# Copia datafetch.sh in /usr/local/bin/
sudo cp datafetch.sh /usr/local/bin/datafetch
sudo chmod +x /usr/local/bin/datafetch

echo "Datafetch è stato installato correttamente."
