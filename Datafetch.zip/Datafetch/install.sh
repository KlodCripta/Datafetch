#!/bin/bash

# Copia datafetch.sh in /usr/local/bin/
sudo cp datafetch.sh /usr/local/bin/datafetch
sudo chmod +x /usr/local/bin/datafetch

echo "Datafetch è stato installato correttamente."

# Funzione per rilevare la presenza di dmidecode
check_dmidecode() {
    if command -v dmidecode &> /dev/null; then
        echo "dmidecode è già installato."
    else
        echo "dmidecode non è installato."
        read -p "Vuoi installare dmidecode per funzionalità avanzate? (y/n): " choice
        if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
            install_dmidecode
        else
            echo "dmidecode non verrà installato. Alcune funzionalità avanzate potrebbero non funzionare."
        fi
    fi
}

# Funzione per installare dmidecode
install_dmidecode() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
            "arch" | "manjaro")
                sudo pacman -Sy dmidecode
                ;;
            "debian" | "ubuntu")
                sudo apt update && sudo apt install -y dmidecode
                ;;
            "fedora")
                sudo dnf install -y dmidecode
                ;;
            "opensuse-leap" | "opensuse-tumbleweed")
                sudo zypper install -y dmidecode
                ;;
            *)
                echo "Distribuzione non riconosciuta. Per favore installa dmidecode manualmente."
                ;;
        esac
    else
        echo "Non è possibile determinare la distribuzione. Per favore installa dmidecode manualmente."
    fi
}

# Funzione per rilevare la presenza di bc
check_bc() {
    if command -v bc &> /dev/null; then
        echo "bc è già installato."
    else
        echo "bc non è installato."
        read -p "Vuoi installare bc per il corretto funzionamento di Datafetch? (y/n): " choice
        if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
            install_bc
        else
            echo "bc non verrà installato. Datafetch potrebbe non funzionare correttamente."
        fi
    fi
}

# Funzione per installare bc
install_bc() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
            "arch" | "manjaro")
                sudo pacman -Sy bc
                ;;
            "debian" | "ubuntu")
                sudo apt update && sudo apt install -y bc
                ;;
            "fedora")
                sudo dnf install -y bc
                ;;
            "opensuse-leap" | "opensuse-tumbleweed")
                sudo zypper install -y bc
                ;;
            *)
                echo "Distribuzione non riconosciuta. Per favore installa bc manualmente."
                ;;
        esac
    else
        echo "Non è possibile determinare la distribuzione. Per favore installa bc manualmente."
    fi
}

# Controllo e installazione di dmidecode e bc
check_dmidecode
check_bc
