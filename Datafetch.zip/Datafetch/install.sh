#!/bin/bash

# Copia datafetch.sh in /usr/local/bin/
sudo cp datafetch.sh /usr/local/bin/datafetch
sudo chmod +x /usr/local/bin/datafetch

echo "Datafetch è stato installato correttamente."

# Funzione per rilevare la presenza di dmidecode
check_dmidecode() {
    if command -v dmidecode &> /dev/null; then
        echo "dmidecode è già installato."
    else
        echo "dmidecode non è installato."
        read -p "Vuoi installare dmidecode per funzionalità avanzate? (y/n): " choice
        if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
            install_dmidecode
        else
            echo "dmidecode non verrà installato. Alcune funzionalità avanzate potrebbero non funzionare."
        fi
    fi
}

# Funzione per installare dmidecode
install_dmidecode() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
            "arch" | "manjaro")
                sudo pacman -Sy dmidecode
                ;;
            "debian" | "ubuntu")
                sudo apt update && sudo apt install -y dmidecode
                ;;
            "fedora")
                sudo dnf install -y dmidecode
                ;;
            "opensuse-leap" | "opensuse-tumbleweed")
                sudo zypper install -y dmidecode
                ;;
            *)
                echo "Distribuzione non riconosciuta. Per favore installa dmidecode manualmente."
                ;;
        esac
    else
        echo "Non è possibile determinare la distribuzione. Per favore installa dmidecode manualmente."
    fi
}

# Controllo e installazione di dmidecode
check_dmidecode
