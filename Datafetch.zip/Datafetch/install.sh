#!/bin/bash

# Funzione per determinare la lingua di sistema
detect_language() {
    case "$LANG" in
        it_* ) lang="it";;  # Italiano
        * ) lang="en";;     # Default a inglese
    esac
}

# Messaggi in italiano
messages_it=(
    "Datafetch è stato installato correttamente."
    "dmidecode è già installato."
    "dmidecode non è installato."
    "Vuoi installare dmidecode per funzionalità avanzate? (y/n): "
    "dmidecode non verrà installato. Alcune funzionalità avanzate potrebbero non funzionare."
    "Distribuzione non riconosciuta. Per favore installa dmidecode manualmente."
    "Non è possibile determinare la distribuzione. Per favore installa dmidecode manualmente."
    "bc è già installato."
    "bc non è installato."
    "Vuoi installare bc per il corretto funzionamento di Datafetch? (y/n): "
    "bc non verrà installato. Datafetch potrebbe non funzionare correttamente."
)

# Messaggi in inglese
messages_en=(
    "Datafetch has been successfully installed."
    "dmidecode is already installed."
    "dmidecode is not installed."
    "Do you want to install dmidecode for advanced features? (y/n): "
    "dmidecode will not be installed. Some advanced features may not work."
    "Unrecognized distribution. Please install dmidecode manually."
    "Cannot determine the distribution. Please install dmidecode manually."
    "bc is already installed."
    "bc is not installed."
    "Do you want to install bc for Datafetch to function correctly? (y/n): "
    "bc will not be installed. Datafetch might not function correctly."
)

# Funzione per visualizzare i messaggi corretti in base alla lingua
message() {
    if [[ "$lang" == "it" ]]; then
        echo "${messages_it[$1]}"
    else
        echo "${messages_en[$1]}"
    fi
}

# Copia datafetch.sh in /usr/local/bin/
sudo cp datafetch.sh /usr/local/bin/datafetch
sudo chmod +x /usr/local/bin/datafetch

message 0  # "Datafetch è stato installato correttamente." / "Datafetch has been successfully installed."

# Funzione per rilevare la presenza di dmidecode
check_dmidecode() {
    if command -v dmidecode &> /dev/null; then
        message 1  # "dmidecode è già installato." / "dmidecode is already installed."
    else
        message 2  # "dmidecode non è installato." / "dmidecode is not installed."
        read -p "$(message 3)" choice  # "Vuoi installare dmidecode?" / "Do you want to install dmidecode?"
        if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
            install_dmidecode
        else
            message 4  # "dmidecode non verrà installato." / "dmidecode will not be installed."
        fi
    fi
}
# Funzione per installare dmidecode
install_dmidecode() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
    # Derivate Arch Linux
    "arch" | "manjaro" | "garuda" | "endeavouros" | "arcolinux" | "artix" | "rebornos" | "parabola" | "chakra" | "archbang")
        sudo pacman -Sy dmidecode
        ;;
    # Derivate Debian e Ubuntu
    "debian" | "ubuntu" | "pop" | "linuxmint" | "elementary" | "zorin" | "kali" | "pureos" | "parrot" | "devuan" | "mx" | "deepin" | "raspbian" | "ubuntu-mate" | "lubuntu" | "xubuntu" | "ubuntu-budgie")
        sudo apt update && sudo apt install -y dmidecode
        ;;
    # Derivate Fedora
    "fedora" | "nobara" | "korora")
        sudo dnf install -y dmidecode
        ;;
    # Derivate openSUSE
    "opensuse-leap" | "opensuse-tumbleweed" | "geckolinux")
        sudo zypper install -y dmidecode
        ;;
    # Altre distribuzioni note
    "gentoo" | "calculate" | "sabayon")
        sudo emerge --ask sys-apps/dmidecode
        ;;
    "void")
        sudo xbps-install -S dmidecode
        ;;
    "alpine")
        sudo apk add dmidecode
        ;;
    *)
        echo "Distribuzione non riconosciuta. Per favore installa dmidecode manualmente."
        ;;
        esac

    else
        echo "Non è possibile determinare la distribuzione. Per favore installa dmidecode manualmente."
    fi
}

# Funzione per rilevare la presenza di bc
check_bc() {
    if command -v bc &> /dev/null; then
        message 7  # "bc è già installato." / "bc is already installed."
    else
        message 8  # "bc non è installato." / "bc is not installed."
        read -p "$(message 9)" choice  # "Vuoi installare bc?" / "Do you want to install bc?"
        if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
            install_bc
        else
            message 10  # "bc non verrà installato." / "bc will not be installed."
        fi
    fi
}

# Funzione per installare bc
install_bc() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
    # Derivate Arch Linux
    "arch" | "manjaro" | "garuda" | "endeavouros" | "arcolinux" | "artix" | "rebornos" | "parabola" | "chakra" | "archbang")
        sudo pacman -Sy bc
        ;;
    # Derivate Debian e Ubuntu
    "debian" | "ubuntu" | "pop" | "linuxmint" | "elementary" | "zorin" | "kali" | "pureos" | "parrot" | "devuan" | "mx" | "deepin" | "raspbian" | "ubuntu-mate" | "lubuntu" | "xubuntu" | "ubuntu-budgie")
        sudo apt update && sudo apt install -y bc
        ;;
    # Derivate Fedora
    "fedora" | "nobara" | "korora")
        sudo dnf install -y bc
        ;;
    # Derivate openSUSE
    "opensuse-leap" | "opensuse-tumbleweed" | "geckolinux")
        sudo zypper install -y bc
        ;;
    # Altre distribuzioni note
    "gentoo" | "calculate" | "sabayon")
        sudo emerge --ask sys-apps/bc
        ;;
    "void")
        sudo xbps-install -S bc
        ;;
    "alpine")
        sudo apk add bc
        ;;
    *)
        echo "Distribuzione non riconosciuta. Per favore installa bc manualmente."
        ;;
        esac
    else
        echo "Non è possibile determinare la distribuzione. Per favore installa bc manualmente."
    fi
}

# Controllo e installazione di dmidecode e bc
detect_language  # Imposta la lingua
check_dmidecode
check_bc
